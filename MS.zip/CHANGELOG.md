# 0.5.3

- fixed Mobile Turret having no collision
- made Cleaning Drone's TZP gas fade in/out as smoothly as i could

# 0.5.2

- fixed Mobile Turret lobotomizing itself

# 0.5.1

- fixed the Cleaning Drone not being scannable
- made log entries properly unlock when scanning the enemies

# 0.5.0

- Release